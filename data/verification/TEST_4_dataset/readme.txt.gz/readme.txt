
TEST_Amin_data.yml

.png files are intermediate results from Dec 22, 2016 version using the included .yml
test4 files are from Amins code intermediate results