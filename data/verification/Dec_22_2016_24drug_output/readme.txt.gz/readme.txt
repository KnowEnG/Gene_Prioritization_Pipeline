This compressed data set includes the .yml file used to generate the output in the results directory:
bootstrap_corrleation.yml
